const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const mysql = require('mysql2/promise');

const app = express();
const PORT = process.env.PORT || 3600;

// ===================================================
// CONEXÃO DIRETA COM O MYSQL (XAMPP - rotadorole)
// ===================================================
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'rotadorole',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// ===================================================
// MIDDLEWARES GERAIS
// ===================================================
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Garante que a pasta uploads existe na raiz do backend
const uploadDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Serve os arquivos de imagem estáticos da pasta /uploads
app.use('/uploads', express.static(uploadDir));

// ===================================================
// CONFIGURAÇÃO DO MULTER (UPLOAD DE ARQUIVOS)
// ===================================================
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const extensao = path.extname(file.originalname);
        cb(null, file.fieldname + '-' + uniqueSuffix + extensao);
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }
});

// ===================================================
// 1. ROTAS DE AUTENTICAÇÃO E USUÁRIOS
// ===================================================

// Rota de Cadastro de Usuário
app.post('/login', async (req, res) => {
    try {
        const { nomeCompleto, email, senha } = req.body;

        const [existe] = await db.query('SELECT * FROM logins WHERE email = ?', [email]);
        if (existe && existe.length > 0) {
            return res.json({ success: false, exists: true, message: 'Usuário já cadastrado!' });
        }

        const sql = `INSERT INTO logins (name, email, password, validated) VALUES (?, ?, ?, ?)`;
        await db.query(sql, [nomeCompleto, email, senha, 1]);

        return res.json({ success: true, message: 'Usuário cadastrado com sucesso!' });
    } catch (error) {
        console.error('Erro no cadastro de usuário:', error);
        return res.status(500).json({ success: false, message: 'Erro no servidor.' });
    }
});

// Rota de Login / Autenticação
app.post('/api/auth', async (req, res) => {
    try {
        const { email, senha } = req.body;

        const [rows] = await db.query('SELECT * FROM logins WHERE email = ? AND password = ?', [email, senha]);

        if (rows && rows.length > 0) {
            const user = rows[0];
            return res.json({
                success: true,
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    avatar: user.avatar || null,
                    capa: user.capa || null,
                    tipoConta: 'usuario'
                }
            });
        } else {
            return res.json({ success: false, message: 'E-mail ou senha incorretos.' });
        }
    } catch (error) {
        console.error('Erro ao autenticar usuário:', error);
        return res.status(500).json({ success: false, message: 'Erro no servidor.' });
    }
});

// Rota para Atualizar Foto de Perfil (Avatar) ou Capa do Usuário
app.post('/api/perfil/upload-foto', upload.single('imagem'), async (req, res) => {
    try {
        const { email, campo } = req.body;

        if (!req.file) {
            return res.status(400).json({ success: false, message: 'Nenhum arquivo enviado.' });
        }

        const nomeArquivo = req.file.filename;

        if (!['avatar', 'capa'].includes(campo)) {
            return res.status(400).json({ success: false, message: 'Campo inválido.' });
        }

        const sql = `UPDATE logins SET ${campo} = ? WHERE email = ?`;
        await db.query(sql, [nomeArquivo, email]);

        return res.json({
            success: true,
            arquivo: nomeArquivo,
            url: `http://localhost:${PORT}/uploads/${nomeArquivo}`
        });
    } catch (error) {
        console.error('Erro ao salvar foto de perfil:', error);
        return res.status(500).json({ success: false, message: 'Erro ao salvar foto.' });
    }
});

// ===================================================
// 2. ROTAS DE EVENTOS
// ===================================================

// Listar todos os eventos
app.get('/eventos', async (req, res) => {
    try {
        const [eventos] = await db.query('SELECT * FROM eventos ORDER BY id DESC');
        return res.json(eventos);
    } catch (error) {
        console.error('Erro ao buscar eventos:', error);
        return res.status(500).json({ success: false, message: 'Erro ao buscar eventos.' });
    }
});

// Cadastrar novo evento com imagem
app.post('/eventos', upload.single('imagem'), async (req, res) => {
    try {
        const { titulo, categoria, descricao, data, horario, duracao, localizacao, cidade, bairro, ingresso, preco, link, nome, email, telefone } = req.body;
        const imagem = req.file ? req.file.filename : null;

        const sql = `
            INSERT INTO eventos 
            (titulo, categoria, descricao, data, horario, duracao, localizacao, cidade, bairro, ingresso, preco, imagem, link, nome, email, telefone) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        await db.query(sql, [titulo, categoria, descricao, data, horario, duracao, localizacao, cidade, bairro, ingresso, preco, imagem, link, nome, email, telefone]);

        return res.json({ success: true, message: 'Evento cadastrado com sucesso!' });
    } catch (error) {
        console.error('Erro ao cadastrar evento:', error);
        return res.status(500).json({ success: false, message: 'Erro ao cadastrar evento.' });
    }
});

// Deletar evento
app.delete('/eventos/:id', async (req, res) => {
    try {
        const { id } = req.params;
        await db.query('DELETE FROM eventos WHERE id = ?', [id]);
        return res.json({ success: true, message: 'Evento excluído com sucesso.' });
    } catch (error) {
        console.error('Erro ao deletar evento:', error);
        return res.status(500).json({ success: false, message: 'Erro ao excluir evento.' });
    }
});

// ===================================================
// 3. ROTAS DE PARCEIROS
// ===================================================
app.post('/parceiros', async (req, res) => {
    try {
        const { name, nameempresa, cnpj, telefone, emailcorporativo, interesse, area, mensagem } = req.body;

        const [existe] = await db.query('SELECT * FROM parceiros WHERE emailcorporativo = ?', [emailcorporativo]);
        if (existe && existe.length > 0) {
            return res.json({ success: false, exists: true, message: 'Parceiro já cadastrado!' });
        }

        const sql = `INSERT INTO parceiros (name, nameempresa, cnpj, telefone, emailcorporativo, interesse, area, mensagem) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
        await db.query(sql, [name, nameempresa, cnpj, telefone, emailcorporativo, interesse, area, mensagem]);

        return res.json({ success: true, message: 'Parceiro cadastrado com sucesso!' });
    } catch (error) {
        console.error('Erro ao cadastrar parceiro:', error);
        return res.status(500).json({ success: false, message: 'Erro no servidor.' });
    }
});

// ===================================================
// INICIALIZAÇÃO DO SERVIDOR
// ===================================================
app.listen(PORT, () => {
    console.log(`Servidor rodando com sucesso na porta ${PORT}`);
});