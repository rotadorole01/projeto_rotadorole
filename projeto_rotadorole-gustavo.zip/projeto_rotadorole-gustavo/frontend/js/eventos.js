const API_URL = "http://localhost:3600/api/destaques";

const carousel = document.getElementById("carousel") || document.getElementById("mainCarousel");
const dotsContainer = document.getElementById("carouselDots");

let currentSlide = 0;
let totalSlides = 0;

async function carregarEventos() {
    try {
        const response = await fetch(API_URL);
        const result = await response.json();

        console.log("Destaques recebidos:", result);

        // Trata tanto se vier direto como Array quanto dentro de { data: [...] }
        const eventos = Array.isArray(result) ? result : (result.data || []);

        if (eventos.length > 0) {
            renderizarCarousel(eventos);
        }
    } catch (error) {
        console.error("Erro ao carregar destaques do carrossel:", error);
    }
}

function renderizarCarousel(eventos) {
    if (!carousel) return;

    carousel.innerHTML = "";
    if (dotsContainer) dotsContainer.innerHTML = "";

    eventos.forEach((evento, index) => {
        const item = document.createElement("div");
        item.classList.add("carousel-item");

        if (index === 0) {
            item.classList.add("active");
        }

        // Usa a URL da imagem tratada da API
        const imagemSrc = evento.imagem.startsWith('http') 
            ? evento.imagem 
            : `http://localhost:3600/uploads/${evento.imagem.replace(/^\/?uploads\/?/, '')}`;

        item.style.backgroundImage = `url('${imagemSrc}')`;
        item.style.backgroundSize = "cover";
        item.style.backgroundPosition = "center";

        item.innerHTML = `
            <div class="carousel-item-overlay">
                <h3>${evento.titulo || ''}</h3>
                <p>${evento.descricao || ''}</p>
                <a href="eventos.html?id=${evento.id || ''}" class="btn">
                    Ver Evento
                </a>
            </div>
        `;

        carousel.appendChild(item);

        // Cria os indicadores (dots) se o container existir
        if (dotsContainer) {
            const dot = document.createElement("span");
            dot.classList.add("carousel-dot");

            if (index === 0) {
                dot.classList.add("active");
            }

            dot.addEventListener("click", () => {
                mostrarSlide(index);
            });

            dotsContainer.appendChild(dot);
        }
    });

    totalSlides = eventos.length;
}

function mostrarSlide(index) {
    const slides = document.querySelectorAll(".carousel-item");
    const dots = document.querySelectorAll(".carousel-dot");

    slides.forEach(slide => slide.classList.remove("active"));
    dots.forEach(dot => dot.classList.remove("active"));

    if (slides[index]) slides[index].classList.add("active");
    if (dots[index]) dots[index].classList.add("active");

    currentSlide = index;
}

const nextBtn = document.getElementById("nextBtn") || document.querySelector(".carousel-btn.next");
if (nextBtn) {
    nextBtn.addEventListener("click", () => {
        currentSlide++;
        if (currentSlide >= totalSlides) {
            currentSlide = 0;
        }
        mostrarSlide(currentSlide);
    });
}

const prevBtn = document.getElementById("prevBtn") || document.querySelector(".carousel-btn.prev");
if (prevBtn) {
    prevBtn.addEventListener("click", () => {
        currentSlide--;
        if (currentSlide < 0) {
            currentSlide = totalSlides - 1;
        }
        mostrarSlide(currentSlide);
    });
}

carregarEventos();